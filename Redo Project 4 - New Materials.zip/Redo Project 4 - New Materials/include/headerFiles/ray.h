#ifndef _RAY_GENERATION_
#define _RAY_GENERATION_
 
#include "scene.h"
#include "renderer.h"
#include "objects.h"


class calculateRay : public Renderer
{
    public:
        calculateRay(){}

        bool TraceRay(Ray const &ray, HitInfo &hInfo, int hitSide) const;

        bool treeTraversal( Node *node, Ray ray, HitInfo &hInfo);
        Color shootRay(int x, int y, Ray const &ray, HitInfo &hInfo);


        // Color shootRay(Ray const &ray, HitInfo &hInfo, int bounceNum);
};


#endif
