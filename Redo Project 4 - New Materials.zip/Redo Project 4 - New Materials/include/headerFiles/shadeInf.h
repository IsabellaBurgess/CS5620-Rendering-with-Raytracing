 
#ifndef _SHADE_INF_HEADER_
#define _SHADE_INF_HEADER_

#include "renderer.h"
#include "scene.h"

class Shadows : public ShadeInfo
{
public: 
    Shadows(std::vector<Light*> const &lightList) : ShadeInfo(lightList) {};

    float TraceShadowRay( Ray const &ray, float t_max) const override;
    
//kl

};
#endif