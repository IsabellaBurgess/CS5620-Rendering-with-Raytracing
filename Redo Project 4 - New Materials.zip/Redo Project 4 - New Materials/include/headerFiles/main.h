 
#ifndef _MAIN_HEADER_
#define _MAIN_HEADER_

#include "renderer.h"

class RayTracer : public Renderer
{
public: 
    void BeginRender();

    bool TraceRay(Ray const &ray, HitInfo &hInfo, int hitSide) const;

    bool TraceShadowRay(Ray const &ray, float t_max, int hitSide);



};
#endif