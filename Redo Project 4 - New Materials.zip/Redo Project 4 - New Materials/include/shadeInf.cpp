// Isabella Burgess - u1408202

#define GLUT_DISABLE_ATEXIT_HACK

#include <thread>

#include <iostream>
#include <GL/glew.h>
#include <GL/glut.h>
#include <GL/gl.h>
#include "cy/cyGL.h"
#include "cy/cyMatrix.h"
#include "headerFiles/shadeInf.h"
#include "headerFiles/ray.h"


using namespace cy;
using namespace std;

calculateRay rayCalculation; 

extern Node rootNode; 


bool TraceShadowRay(Ray const &ray, float t_max, int hitSide){
    HitInfo hitInf = HitInfo();
    hitInf.Init();

    bool hit =  rayCalculation.treeTraversal(&rootNode, ray, hitInf);
    
    if(hitInf.z > t_max) 
    {
        hit = false;
    }
            // printf("Hit tracker: %d\n ", hitTracker);

    return hit;
}

bool shadowRay(Node *node, Ray ray, HitInfo &hInfo){
    bool hitTracker = false;
    Ray transformedRay = node->ToNodeCoords(ray);
    // hInfo.node = node;
    Object* currentObj = node->GetNodeObj();

    // printf("in hitObject\n");

    if(currentObj != nullptr){
        // printf("true2\n");

        if(currentObj->IntersectRay(transformedRay, hInfo, 1))
        {
            // printf("true %d\n ", hitTracker);
            // node->FromNodeCoords(hInfo);

            return true;

        }
    }
    for(int i = 0; i < node->GetNumChild(); i++){
        Node *child = node->GetChild(i);
            // printf("true %d\n ", hitTracker);

        if(shadowRay(child, transformedRay, hInfo) == true)
        {
            return true;

        }
    }

    return false;
}
