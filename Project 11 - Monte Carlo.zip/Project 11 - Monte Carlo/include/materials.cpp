#include "headerFiles/materials.h"
#include "headerFiles/renderer.h"
#include "headerFiles/ray.h"



#include "cy/cyMatrix.h"
#include "cy/cyVector.h"
#include "headerFiles/scene.h"
#include "headerFiles/shadeInf.h"


using namespace cy;

extern MaterialList matList; 
extern Camera cam;

extern calculateRay rayCalculation; 
extern RNG rng;
extern int montCarloBounceNum; 
extern int montCarloSamples;

 



Color MtlBlinn::Shade(ShadeInfo const &shadeInfo) const
{
	Vec3f const camera = shadeInfo.V();
    Vec3f const hitPos = shadeInfo.P();
    Vec3f const norm = shadeInfo.N();

    float gloss = Glossiness().GetValue();
    Vec3f lightDir = Vec3f(0,0,0 );
    // float lightIntensity = 1.0;

    Color ambientColor = Color(0.0, 0.0, 0.0);
    Color blinnColor = Color(0.0,0.0,0.0);
    
    Color absorbValue = this->absorption;

    //this!! this is what needs to get updated and changed
    // TexturedColor baseTex = this->Diffuse();
	Color baseColor = this->Diffuse().Eval(shadeInfo.UVW());
    Color reflectColor = this->Specular().Eval(shadeInfo.UVW());

    
    Color reflectValue = this->reflection.GetValue();
    Color refractValue = this->refraction.GetValue();
    
    Color reflection = Color(0, 0, 0);
    Color refraction = Color(0, 0, 0);

    if(refractValue != Color(0, 0, 0) && shadeInfo.CanBounce()){

        // printf("glass!\n");
        float ior = this->IOR();
        float eta = 1/ior;

        if(!shadeInfo.IsFront())
        {
            eta = ior/1;
        }

        float refractCosThetaO = pow((camera % norm),2.0);
        float refractCosThetaTSquared = 1.0 - (pow(eta, 2.0)*(1.0-(refractCosThetaO)));

        if(refractCosThetaTSquared <= 0.0f){
            reflectValue.SetWhite();
        }

        else{
            float phiOffset = Halton(shadeInfo.CurrentPixelSample(), 2) + rng.RandomFloat();
            float thetaOffset = Halton(shadeInfo.CurrentPixelSample(), 3) + rng.RandomFloat();

            Vec3f u = Vec3f(0, 0, 0); 
            Vec3f v = Vec3f(0, 0, 0);

            norm.GetOrthonormals(u, v);

            if(phiOffset > 1.0){
                phiOffset = phiOffset - 1;
            }

            if(thetaOffset > 1.0){
                thetaOffset = thetaOffset - 1;
            }

            float phi = 2.0*Pi<float>() * phiOffset;
            float cosTheta = pow(1 - thetaOffset, 1.0/(glossiness.GetValue() + 1.0));

            float sinTheta = sqrt(1.0 - pow(cosTheta, 2.0));

            Vec3f localH = Vec3f(sinTheta * cos(phi), sinTheta * sin(phi), cosTheta);  
            Vec3f worldH = (localH.x * u) + (localH.y * v) + (localH.z * norm);

            Vec3f refractDir;

            refractDir = -eta * camera - (sqrt(refractCosThetaTSquared)- eta*(camera % worldH))*worldH;
                // printf("front hit 1\n");
 
            Ray refractRay; 
            refractRay.dir = refractDir ;

            refractRay.p = hitPos ;
            
            HitInfo refractHit = HitInfo();
            refractHit.Init(); 
            
            float dist = BIGFLOAT;

            refraction = shadeInfo.TraceSecondaryRay(refractRay, dist);

            
            if(!shadeInfo.IsFront()){
                refraction.r = refraction.r*exp(-absorbValue.r*dist);
                refraction.g = refraction.g*exp(-absorbValue.g*dist);
                refraction.b = refraction.b*exp(-absorbValue.b*dist);

            }

            //change refraction to the current texture point
            refraction = refraction * refractValue;
        }

    }
    
    if(reflectValue != Color(0, 0, 0) && shadeInfo.CanBounce())
    { 
        float phiOffset = Halton(shadeInfo.CurrentPixelSample(), 2) + rng.RandomFloat();
        float thetaOffset = Halton(shadeInfo.CurrentPixelSample(), 3) + rng.RandomFloat();

        Vec3f u = Vec3f(0, 0, 0); 
        Vec3f v = Vec3f(0, 0, 0);

        norm.GetOrthonormals(u, v);

        if(phiOffset > 1.0){
            phiOffset = phiOffset - 1;
        }

        if(thetaOffset > 1.0){
            thetaOffset = thetaOffset - 1;
        }

        float phi = 2.0*Pi<float>() * phiOffset;
        float cosTheta = pow(1 - thetaOffset, 1.0/(glossiness.GetValue() + 1.0));

        float sinTheta = sqrt(1.0 - pow(cosTheta, 2.0));

        Vec3f localH = Vec3f(sinTheta * cos(phi), sinTheta * sin(phi), cosTheta);  
        Vec3f worldH = (localH.x * u) + (localH.y * v) + (localH.z * norm);

        // Vec3f h = (norm * cosTheta) + (u )

        Vec3f reflectDir = 2.0*(worldH%camera)*worldH - camera;

        Ray reflectRay;
        reflectRay.dir = reflectDir;

        reflectRay.p = hitPos + (reflectRay.dir * 0.01);

        HitInfo reflectHit = HitInfo();
        reflectHit.Init();

        //create a shootSecondaryRay method. pass in the bounce number, subtract 1 each time. 
        //thats it thats the only difference. check that bounce number is > 0 
        float dist = BIGFLOAT;

        reflection = shadeInfo.TraceSecondaryRay(reflectRay, dist) * reflectValue;
        // return reflectColor;
    }

    for(int i = 0; i < shadeInfo.NumLights(); i++){
        const Light* currentLight = shadeInfo.GetLight(i);
        // printf("light number is %s\n", currentLight->GetName());

        Color intensity = currentLight->Illuminate(shadeInfo, lightDir);

        if(shadeInfo.CurrentBounce() < montCarloBounceNum){
            for(int j = 0; j < montCarloSamples; j++){
                float phiOffset = Halton(j, 2) + rng.RandomFloat();
                float thetaOffset = Halton(j, 3) + rng.RandomFloat();

                Vec3f u = Vec3f(0, 0, 0); 
                Vec3f v = Vec3f(0, 0, 0);

                norm.GetOrthonormals(u, v);

                if(phiOffset > 1.0){
                    phiOffset = phiOffset - 1;
                }

                if(thetaOffset > 1.0){
                    thetaOffset = thetaOffset - 1;
                }

                float phi = 1/(2.0*Pi<float>());
                float cosTheta =  thetaOffset;

                float sinTheta = sqrt(1.0 - pow(cosTheta, 2.0));

                Vec3f localDir = Vec3f(sinTheta * cos(phi), sinTheta * sin(phi), cosTheta);  
                Vec3f worldDir = (localDir.x * u) + (localDir.y * v) + (localDir.z * norm);

                Ray montCarloRay = Ray(hitPos, worldDir);

                float dist = BIGFLOAT;

                ambientColor += shadeInfo.TraceSecondaryRay(montCarloRay, dist) * cosTheta * 2; 
            }

            ambientColor = ambientColor/montCarloSamples;
        }
        // if(currentLight->IsAmbient()){
        //     ambientColor += intensity * baseColor;
        // }


        else{
            // printf("Current light is %s\n", currentLight->GetName());

            lightDir = Normalize(lightDir);

            Vec3f n = shadeInfo.N();
            Vec3f h = Normalize(lightDir+camera);
            // printf("Normals are [%f, %f, %f]\n", n.x, n.y, n.z);
            // printf("Object name is %s\n", hInfo.node->GetName());
            
                
            float cosPhi = Max((n % h), 0.0f);

            float cosTheta = Max((n % lightDir), 0.0f);

            
                
            Color specularLight =  (reflectColor * pow(cosPhi, gloss)) * ((gloss+2)/(8*Pi<float>()));
            Color difuseLight = (cosTheta * baseColor) * (1/Pi<float>());
            blinnColor += (intensity * (difuseLight + specularLight));


        }
    }
    // printf("Blinn color = [%f, %f, %f]\n", blinnColor.r, blinnColor.g, blinnColor.b);

    return blinnColor + ambientColor + reflection + refraction;
}

Color MtlPhong::Shade(ShadeInfo const &shadeInfo ) const
{
    return Color();
}

Color MtlMicrofacet::Shade(ShadeInfo const &shadeInfo ) const
{
    return Color();
}